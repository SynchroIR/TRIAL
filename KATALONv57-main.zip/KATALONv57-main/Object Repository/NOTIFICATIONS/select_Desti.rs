<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Desti</name>
   <tag></tag>
   <elementGuidId>f1c1c0ce-96b9-4e84-ba8e-e79ce76d42de</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='message_recipient[]']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;message_recipient[]&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>message_recipient[]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control message-recipient span12</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Element</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        Administrators
                                        Contact Customer
                                        Contact Site
                                        Contact Job
                                        Technician (main)
                                        Technicians (all)
                                        Managers
                                        Job Creator
                                        Report Field (Enter label)
                                        Custom (Enter manually)
                                    Customer: Equipements Garantis2Equipment: Email equipementSite: Email2Job: EmailTechnician: EmailEmailCustomer: Contact 1Customer: Contact 2 </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;notification-messages&quot;)/blockquote[@class=&quot;message-container&quot;]/div[@class=&quot;row-fluid&quot;]/div[@class=&quot;control-group span4&quot;]/div[2]/div[@class=&quot;controls&quot;]/select[@class=&quot;form-control message-recipient span12&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='message_recipient[]']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='notification-messages']/blockquote/div/div/div[2]/div/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Send To'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Method'])[1]/following::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/preceding::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message'])[1]/preceding::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'message_recipient[]' and (text() = '
                                        Administrators
                                        Contact Customer
                                        Contact Site
                                        Contact Job
                                        Technician (main)
                                        Technicians (all)
                                        Managers
                                        Job Creator
                                        Report Field (Enter label)
                                        Custom (Enter manually)
                                    Customer: Equipements Garantis2Equipment: Email equipementSite: Email2Job: EmailTechnician: EmailEmailCustomer: Contact 1Customer: Contact 2 ' or . = '
                                        Administrators
                                        Contact Customer
                                        Contact Site
                                        Contact Job
                                        Technician (main)
                                        Technicians (all)
                                        Managers
                                        Job Creator
                                        Report Field (Enter label)
                                        Custom (Enter manually)
                                    Customer: Equipements Garantis2Equipment: Email equipementSite: Email2Job: EmailTechnician: EmailEmailCustomer: Contact 1Customer: Contact 2 ')]</value>
   </webElementXpaths>
</WebElementEntity>
