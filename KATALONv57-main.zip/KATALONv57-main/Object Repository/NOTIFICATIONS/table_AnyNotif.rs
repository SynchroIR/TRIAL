<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>table_AnyNotif</name>
   <tag></tag>
   <elementGuidId>a744e573-beec-4ee2-b47d-c0b0b3e95757</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='data']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#data</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>table</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>100%</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>data</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>table table-striped table-bordered table-hover data-table dataTable no-footer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-table</name>
      <type>Main</type>
      <value>notifications</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>data_info</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate Delete
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;data&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//table[@id='data']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='data_wrapper']/div/div[2]/table</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Processing...'])[1]/following::table[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div[2]/div/div/div/div[2]/table</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//table[@id = 'data' and (text() = '
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate Delete
            ' or . = '
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate Delete
            ')]</value>
   </webElementXpaths>
</WebElementEntity>
