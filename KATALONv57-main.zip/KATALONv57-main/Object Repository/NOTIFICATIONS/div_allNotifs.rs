<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_allNotifs</name>
   <tag></tag>
   <elementGuidId>775ef4be-ddcc-4c8a-a0f4-9824656e8485</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='data_wrapper']/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.table-responsive.scroll-on</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>table-responsive scroll-on</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate Delete
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ajax-modal&quot;)/div[@class=&quot;modal-dialog modal-xl modal-dialog-slideout&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;st-datatables-container&quot;]/div[@id=&quot;data_wrapper&quot;]/div[@id=&quot;data_wrapper&quot;]/div[@class=&quot;st-datatable&quot;]/div[@class=&quot;table-responsive scroll-on&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='data_wrapper']/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Processing...'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div[2]/div/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate Delete
            ' or . = '
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobScheduledTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Text Message [Custom] +33635421384 Email [Custom] melanie@synchroteam.com Chauffage ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email Contact Customer Engineering ACME Corp...Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobCreated- Text Message [Custom] +33606060606 Email [Custom] irsynchroteam@gmail.com Text Message [Custom] +33606060606 JFTSMSActions Notification Edit Duplicate Delete
            ')]</value>
   </webElementXpaths>
</WebElementEntity>
