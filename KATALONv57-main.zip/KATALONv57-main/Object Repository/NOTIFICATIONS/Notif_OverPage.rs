<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Notif_OverPage</name>
   <tag></tag>
   <elementGuidId>3b7d12d4-e331-4453-853a-1e33550a5def</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ajax-modal']/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            







    
        
             Text Messages credit balance low
        
        

            You have 0 Text Message credits remaining. Purchase more credits
        
    
    
        
             Add102550100 Rows12Processing...
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate Delete
            Rows 1 to 25 of 4112
        
        
                
                     Last Sent Text Messages
                
            
                 Last Sent Emails
            
        
    



        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ajax-modal&quot;)/div[@class=&quot;modal-dialog modal-xl modal-dialog-slideout&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ajax-modal']/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notifications'])[2]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download App for iOS or Android'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            







    
        
             Text Messages credit balance low
        
        

            You have 0 Text Message credits remaining. Purchase more credits
        
    
    
        
             Add102550100 Rows12Processing...
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate Delete
            Rows 1 to 25 of 4112
        
        
                
                     Last Sent Text Messages
                
            
                 Last Sent Emails
            
        
    



        ' or . = '
            







    
        
             Text Messages credit balance low
        
        

            You have 0 Text Message credits remaining. Purchase more credits
        
    
    
        
             Add102550100 Rows12Processing...
                
                    
                            
                                Any
                                Created
                                Draft
                                Scheduled
                                Started
                                Paused
                                Completed
                                Validated
                                Cancelled
                                Unscheduled
                                Deleted
                            AnyManagerCustomerTechnician
                    ElementEventEvent OriginMessagesFiltersActions
                
                JobDraftManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobScheduledManager Email [Custom] ouafae.bahari.synchroteam@gmail.com 1-State (30mn) 123MARCOActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1-draft.nodelay@gmail.com testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 2-schedule.nodelay@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 3-start.nodelay@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 4-complete.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 5-validate.nodelay@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6-draft.10before@gmail.com Text Message [Custom] +33635421384 Text Message Technicians (all) Email Technicians (all) testdelay TESTDELAYActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 7-schedule.11before@gmail.com TESTDELAYActions Notification Edit Duplicate DeleteJobStarted- Email [Custom] 8-start.12after@gmail.com testdelayActions Notification Edit Duplicate DeleteJobCompletedTechnician Email [Custom] 9-complete.13after@gmail.comActions Notification Edit Duplicate DeleteJobValidatedManager Email [Custom] 10-validate.14after@gmail.comActions Notification Edit Duplicate DeleteJobCreated- Email [Custom] tous@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 2onceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 3oncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 4oncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 5notonceclientjobtype.tous@gmail.com 1- Location assessment (1h) ACME Corp..Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 6notoncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraft- Email [Custom] 7notonceclient.tous@gmail.com ACME Corp..Actions Notification Edit Duplicate DeleteJobDraftManager Email [Custom] 8notoncejobtype.ag@gmail.com 1-State (30mn)Actions Notification Edit Duplicate DeleteJobDraftTechnician Email [Custom] 9notoncenofilter.tech@gmail.comActions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 0onceclientjobtype.tous@gmail.com 1-State (30mn) ACME Corp..Actions Notification Edit Duplicate DeleteJobScheduled- Email [Custom] 1oncejobtype.tous@gmail.com 1-State (30mn)Actions Notification Edit Duplicate Delete
            Rows 1 to 25 of 4112
        
        
                
                     Last Sent Text Messages
                
            
                 Last Sent Emails
            
        
    



        ')]</value>
   </webElementXpaths>
</WebElementEntity>
